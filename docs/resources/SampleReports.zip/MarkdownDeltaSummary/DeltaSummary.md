# Delta Summary
|||||
|:---|---:|---:|---:|
| Generated on: | 09.02.2023 - 21:29 | | |
| Description | **Previous** | **Current** | **Delta** |
| Coverage date: | 09.02.2022 - 20:50 | 09.02.2023 - 21:29 | |
| **Line coverage:** | 58.4% | 66.4% | 8.0% |
| Covered lines: | 73 | 83 | 10 |
| Coverable lines: | 125 | 125 | 0 |
| Total lines: | 260 | 260 | 0 |
| **Branch coverage:** | 45% | 50% | 5% |
| Covered branches: | 27 | 3 | -24 |
| Total branches: | 60 | 6 | -54 |
| **Method coverage:** | 66.6% | 58.3% | -8.3% |
| Covered methods: | 16 | 14 | -2 |
| Total methods: | 24 | 24 | 0 |
