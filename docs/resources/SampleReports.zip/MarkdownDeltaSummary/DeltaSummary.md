# Delta Summary
|||||
|:---|---:|---:|---:|
| Generated on: | 21.02.2026 - 22:51 | | |
| Description | **Previous** | **Current** | **Delta** |
| Coverage date: | 09.02.2022 - 20:50 | 21.02.2026 - 22:51 | |
| **Line coverage:** | 58.4% | 69.4% | 11.0% |
| Covered lines: | 73 | 75 | 2 |
| Coverable lines: | 125 | 108 | -17 |
| Total lines: | 260 | 260 | 0 |
| **Branch coverage:** | 45% | 50% | 5% |
| Covered branches: | 27 | 4 | -23 |
| Total branches: | 60 | 8 | -52 |
| **Method coverage:** | 70.8% | 66.6% | -4.2% |
| **Full method coverage:** | 37.5% | 50% | 12.5% |
| Covered methods: | 17 | 16 | -1 |
| Fully covered methods: | 9 | 12 | 3 |
| Total methods: | 24 | 24 | 0 |
