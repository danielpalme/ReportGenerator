# Delta Summary
|||||
|:---|---:|---:|---:|
| Generated on: | 03.02.2024 - 21:27 | | |
| Description | **Previous** | **Current** | **Delta** |
| Coverage date: | 09.02.2022 - 20:50 | 03.02.2024 - 21:27 | |
| **Line coverage:** | 58.4% | 69.4% | 11.0% |
| Covered lines: | 73 | 75 | 2 |
| Coverable lines: | 125 | 108 | -17 |
| Total lines: | 260 | 260 | 0 |
| **Branch coverage:** | 45% | 50% | 5% |
| Covered branches: | 27 | 4 | -23 |
| Total branches: | 60 | 8 | -52 |
| **Method coverage:** | 66.6% | 66.6% | 0.0% |
| Covered methods: | 16 | 16 | 0 |
| Total methods: | 24 | 24 | 0 |
