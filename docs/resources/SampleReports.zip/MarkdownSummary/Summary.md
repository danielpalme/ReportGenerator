# Summary

|||
|:---|:---|
| Generated on: | 27.07.2026 - 21:06:33 |
| Parser: | OpenCover |
| Assemblies: | 1 |
| Classes: | 4 |
| Files: | 5 |
| **Line coverage:** | 69.4% (75 of 108) |
| Covered lines: | 75 |
| Uncovered lines: | 33 |
| Coverable lines: | 108 |
| Total lines: | 260 |
| **Branch coverage:** | 50% (4 of 8) |
| Covered branches: | 4 |
| Total branches: | 8 |
| **Method coverage:** | 66.6% (16 of 24) |
| **Full method coverage:** | 50% (12 of 24) |
| Covered methods: | 16 |
| Fully covered methods: | 12 |
| Total methods: | 24 |

# Risk Hotspots

No risk hotspots found.

# Coverage

| **Name** | **Covered** | **Uncovered** | **Coverable** | **Total** | **Line coverage** | **Covered** | **Total** | **Branch coverage** | **Covered** | **Total** | **Method coverage** | **Full method coverage** |
|:---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| **Sample** | **75** | **33** | **108** | **260** | **69.4%** | **4** | **8** | **50%** | **16** | **24** | **66.6%** | **50%** |
| Sample.PartialClass | 12 | 10 | 22 | 53 | 54.5% | 1 | 2 | 50% | 3 | 6 | 50% | 33.3% |
| Test.Program | 15 | 0 | 15 | 84 | 100% | 0 | 0 |  | 3 | 3 | 100% | 100% |
| Test.TestClass | 24 | 9 | 33 | 38 | 72.7% | 2 | 4 | 50% | 4 | 5 | 80% | 60% |
| Test.TestClass2 | 24 | 14 | 38 | 85 | 63.1% | 1 | 2 | 50% | 6 | 10 | 60% | 40% |

