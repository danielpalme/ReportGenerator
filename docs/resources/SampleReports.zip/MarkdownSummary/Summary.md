﻿# Summary
|||
|:---|:---|
| Generated on: | 12.11.2021 - 21:07:23 |
| Parser: | OpenCoverParser |
| Assemblies: | 1 |
| Classes: | 2 |
| Files: | 3 |
| Covered lines: | 24 |
| Uncovered lines: | 19 |
| Coverable lines: | 43 |
| Total lines: | 91 |
| Line coverage: | 55.8% (24 of 43) |
| Covered branches: | 2 |
| Total branches: | 4 |
| Branch coverage: | 50% (2 of 4) |
| Covered methods: | 4 |
| Total methods: | 8 |
| Method coverage: | 50% (4 of 8) |

|**Name**|**Covered**|**Uncovered**|**Coverable**|**Total**|**Line coverage**|**Covered**|**Total**|**Branch coverage**|**Covered**|**Total**|**Method coverage**|
|:---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
|**Sample**|**24**|**19**|**43**|**91**|**55.8%**|**2**|**4**|**50%**|**4**|**8**|**50%**|
|Sample.PartialClass|12|10|22|53|54.5%|1|2|50%|3|6|50%|
|Sample.TestClass|12|9|21|38|57.1%|1|2|50%|1|2|50%|
