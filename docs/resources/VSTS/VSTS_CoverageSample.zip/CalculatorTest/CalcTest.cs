﻿using Calculator;
using Xunit;

namespace CalculatorTest
{
    public class CalcTest
    {
        [Fact]
        public void AddTest()
        {
            var sut = new Calc();
            Assert.Equal(3, sut.Add(1, 2));
        }
    }
}
